import sys
from _typeshed import structseq
from collections.abc import Callable, Iterable
from enum import IntEnum
from types import FrameType
from typing import Any, Final, TypeAlias, final
from typing_extensions import Never

NSIG: int

class Signals(IntEnum):
    SIGFPE = 8
    SIGILL = 4
    SIGINT = 2
    SIGSEGV = 11
    SIGTERM = 15

    if sys.platform == "win32":
        SIGABRT = 22
        SIGBREAK = 21
        CTRL_C_EVENT = 0
        CTRL_BREAK_EVENT = 1
    else:
        SIGABRT = 6
        SIGALRM = 14
        SIGBUS = 7
        SIGCHLD = 17
        SIGCONT = 18
        SIGHUP = 1
        SIGIO = 29
        SIGIOT = 6
        SIGKILL = 9
        SIGPIPE = 13
        SIGPROF = 27
        SIGQUIT = 3
        SIGSTOP = 19
        SIGSYS = 31
        SIGTRAP = 5
        SIGTSTP = 20
        SIGTTIN = 21
        SIGTTOU = 22
        SIGURG = 23
        SIGUSR1 = 10
        SIGUSR2 = 12
        SIGVTALRM = 26
        SIGWINCH = 28
        SIGXCPU = 24
        SIGXFSZ = 25
        if sys.platform != "linux":
            SIGEMT = 7
            SIGINFO = 29
        if sys.platform != "darwin":
            SIGCLD = 17
            SIGPOLL = 29
            SIGPWR = 30
            SIGRTMAX = 64
            SIGRTMIN = 34
            if sys.version_info >= (3, 11):
                SIGSTKFLT = 16

class Handlers(IntEnum):
    SIG_DFL = 0
    SIG_IGN = 1

SIG_DFL: Final = Handlers.SIG_DFL
SIG_IGN: Final = Handlers.SIG_IGN

_SIGNUM: TypeAlias = int | Signals
_HANDLER: TypeAlias = Callable[[int, FrameType | None], Any] | int | Handlers | None

def default_int_handler(signalnum: int, frame: FrameType | None, /) -> Never: ...
def getsignal(signalnum: _SIGNUM) -> _HANDLER: ...
def signal(signalnum: _SIGNUM, handler: _HANDLER) -> _HANDLER: ...

SIGABRT: Final = Signals.SIGABRT
SIGFPE: Final = Signals.SIGFPE
SIGILL: Final = Signals.SIGILL
SIGINT: Final = Signals.SIGINT
SIGSEGV: Final = Signals.SIGSEGV
SIGTERM: Final = Signals.SIGTERM

if sys.platform == "win32":
    SIGBREAK: Final = Signals.SIGBREAK
    CTRL_C_EVENT: Final = Signals.CTRL_C_EVENT
    CTRL_BREAK_EVENT: Final = Signals.CTRL_BREAK_EVENT
else:
    if sys.platform != "linux":
        SIGINFO: Final = Signals.SIGINFO
        SIGEMT: Final = Signals.SIGEMT
    SIGALRM: Final = Signals.SIGALRM
    SIGBUS: Final = Signals.SIGBUS
    SIGCHLD: Final = Signals.SIGCHLD
    SIGCONT: Final = Signals.SIGCONT
    SIGHUP: Final = Signals.SIGHUP
    SIGIO: Final = Signals.SIGIO
    SIGIOT: Final = Signals.SIGABRT  # alias
    SIGKILL: Final = Signals.SIGKILL
    SIGPIPE: Final = Signals.SIGPIPE
    SIGPROF: Final = Signals.SIGPROF
    SIGQUIT: Final = Signals.SIGQUIT
    SIGSTOP: Final = Signals.SIGSTOP
    SIGSYS: Final = Signals.SIGSYS
    SIGTRAP: Final = Signals.SIGTRAP
    SIGTSTP: Final = Signals.SIGTSTP
    SIGTTIN: Final = Signals.SIGTTIN
    SIGTTOU: Final = Signals.SIGTTOU
    SIGURG: Final = Signals.SIGURG
    SIGUSR1: Final = Signals.SIGUSR1
    SIGUSR2: Final = Signals.SIGUSR2
    SIGVTALRM: Final = Signals.SIGVTALRM
    SIGWINCH: Final = Signals.SIGWINCH
    SIGXCPU: Final = Signals.SIGXCPU
    SIGXFSZ: Final = Signals.SIGXFSZ

    class ItimerError(OSError): ...
    ITIMER_PROF: int
    ITIMER_REAL: int
    ITIMER_VIRTUAL: int

    class Sigmasks(IntEnum):
        SIG_BLOCK = 0
        SIG_UNBLOCK = 1
        SIG_SETMASK = 2

    SIG_BLOCK: Final = Sigmasks.SIG_BLOCK
    SIG_UNBLOCK: Final = Sigmasks.SIG_UNBLOCK
    SIG_SETMASK: Final = Sigmasks.SIG_SETMASK
    def alarm(seconds: int, /) -> int: ...
    def getitimer(which: int, /) -> tuple[float, float]: ...
    def pause() -> None: ...
    def pthread_kill(thread_id: int, signalnum: int, /) -> None: ...
    def pthread_sigmask(how: int, mask: Iterable[int]) -> set[_SIGNUM]: ...
    def setitimer(which: int, seconds: float, interval: float = 0.0, /) -> tuple[float, float]: ...
    def siginterrupt(signalnum: int, flag: bool, /) -> None: ...
    def sigpending() -> Any: ...
    def sigwait(sigset: Iterable[int]) -> _SIGNUM: ...
    if sys.platform != "darwin":
        SIGCLD: Final = Signals.SIGCHLD  # alias
        SIGPOLL: Final = Signals.SIGIO  # alias
        SIGPWR: Final = Signals.SIGPWR
        SIGRTMAX: Final = Signals.SIGRTMAX
        SIGRTMIN: Final = Signals.SIGRTMIN
        if sys.version_info >= (3, 11):
            SIGSTKFLT: Final = Signals.SIGSTKFLT

        @final
        class struct_siginfo(structseq[int], tuple[int, int, int, int, int, int, int]):
            __match_args__: Final = ("si_signo", "si_code", "si_errno", "si_pid", "si_uid", "si_status", "si_band")

            @property
            def si_signo(self) -> int: ...
            @property
            def si_code(self) -> int: ...
            @property
            def si_errno(self) -> int: ...
            @property
            def si_pid(self) -> int: ...
            @property
            def si_uid(self) -> int: ...
            @property
            def si_status(self) -> int: ...
            @property
            def si_band(self) -> int: ...

        def sigtimedwait(sigset: Iterable[int], timeout: float, /) -> struct_siginfo | None: ...
        def sigwaitinfo(sigset: Iterable[int], /) -> struct_siginfo: ...

def strsignal(signalnum: _SIGNUM, /) -> str | None: ...
def valid_signals() -> set[Signals]: ...
def raise_signal(signalnum: _SIGNUM, /) -> None: ...
def set_wakeup_fd(fd: int, /, *, warn_on_full_buffer: bool = True) -> int: ...

if sys.platform == "linux":
    def pidfd_send_signal(pidfd: int, sig: int, siginfo: None = None, flags: int = 0, /) -> None: ...

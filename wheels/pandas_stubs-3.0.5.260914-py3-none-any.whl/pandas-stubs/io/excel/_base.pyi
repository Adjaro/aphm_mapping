from collections.abc import (
    Callable,
    Hashable,
    Iterable,
    Mapping,
    Sequence,
)
from types import TracebackType
from typing import (
    Any,
    BinaryIO,
    Generic,
    Literal,
    Self,
    TypeAlias,
    overload,
)

from odf.opendocument import OpenDocument  # pyright: ignore[reportMissingTypeStubs]
from openpyxl.workbook.workbook import Workbook
from pandas.core.frame import DataFrame
from pyxlsb.workbook import (  # pyright: ignore[reportMissingTypeStubs]
    Workbook as PyXlsbWorkbook,
)
from typing_extensions import TypeVar
from xlrd.book import Book
from xlsxwriter import (  # pyright: ignore[reportMissingTypeStubs]
    Workbook as XlsxWorkbook,
)

from pandas._libs.lib import NoDefault
from pandas._typing import (
    Dtype,
    DtypeBackend,
    ExcelReadEngine,
    ExcelWriteEngine,
    ExcelWriterIfSheetExists,
    FilePath,
    IntStrT,
    ListLikeHashable,
    ReadBuffer,
    StorageOptions,
    UsecolsArgType,
)

@overload
def read_excel(
    io: (
        FilePath
        | ReadBuffer[bytes]
        | ExcelFile
        | Workbook
        | Book
        | OpenDocument
        | PyXlsbWorkbook
    ),
    sheet_name: list[IntStrT],
    *,
    header: int | Sequence[int] | None = ...,
    names: ListLikeHashable | None = ...,
    index_col: int | Sequence[int] | str | None = ...,
    usecols: str | UsecolsArgType = ...,
    dtype: str | Dtype | Mapping[str, str | Dtype] | None = ...,
    engine: ExcelReadEngine | None = ...,
    converters: Mapping[int | str, Callable[[Any], Any]] | None = ...,
    true_values: Iterable[Hashable] | None = ...,
    false_values: Iterable[Hashable] | None = ...,
    skiprows: int | Sequence[int] | Callable[[object], bool] | None = ...,
    nrows: int | None = ...,
    na_values: Sequence[str] | dict[str | int, Sequence[str]] | None = ...,
    keep_default_na: bool = ...,
    na_filter: bool = ...,
    verbose: bool = ...,
    parse_dates: (
        bool
        | Sequence[int]
        | Sequence[Sequence[str] | Sequence[int]]
        | dict[str, Sequence[int] | list[str]]
    ) = ...,
    date_format: dict[Hashable, str] | str | None = ...,
    thousands: str | None = ...,
    decimal: str = ...,
    comment: str | None = ...,
    skipfooter: int = ...,
    storage_options: StorageOptions = ...,
    dtype_backend: DtypeBackend | NoDefault = ...,
    engine_kwargs: dict[str, Any] | None = ...,
) -> dict[IntStrT, DataFrame]: ...
@overload
def read_excel(
    io: (
        FilePath
        | ReadBuffer[bytes]
        | ExcelFile
        | Workbook
        | Book
        | OpenDocument
        | PyXlsbWorkbook
    ),
    sheet_name: None,
    *,
    header: int | Sequence[int] | None = ...,
    names: ListLikeHashable | None = ...,
    index_col: int | Sequence[int] | str | None = ...,
    usecols: str | UsecolsArgType = ...,
    dtype: str | Dtype | Mapping[str, str | Dtype] | None = ...,
    engine: ExcelReadEngine | None = ...,
    converters: Mapping[int | str, Callable[[Any], Any]] | None = ...,
    true_values: Iterable[Hashable] | None = ...,
    false_values: Iterable[Hashable] | None = ...,
    skiprows: int | Sequence[int] | Callable[[object], bool] | None = ...,
    nrows: int | None = ...,
    na_values: Sequence[str] | dict[str | int, Sequence[str]] | None = ...,
    keep_default_na: bool = ...,
    na_filter: bool = ...,
    verbose: bool = ...,
    parse_dates: (
        bool
        | Sequence[int]
        | Sequence[Sequence[str] | Sequence[int]]
        | dict[str, Sequence[int] | list[str]]
    ) = ...,
    date_format: dict[Hashable, str] | str | None = ...,
    thousands: str | None = ...,
    decimal: str = ...,
    comment: str | None = ...,
    skipfooter: int = ...,
    storage_options: StorageOptions = ...,
    dtype_backend: DtypeBackend | NoDefault = ...,
    engine_kwargs: dict[str, Any] | None = ...,
) -> dict[str, DataFrame]: ...
@overload
# mypy says this won't be matched
def read_excel(  # type: ignore[overload-cannot-match]
    io: (
        FilePath
        | ReadBuffer[bytes]
        | ExcelFile
        | Workbook
        | Book
        | OpenDocument
        | PyXlsbWorkbook
    ),
    sheet_name: list[int | str],
    *,
    header: int | Sequence[int] | None = ...,
    names: ListLikeHashable | None = ...,
    index_col: int | Sequence[int] | str | None = ...,
    usecols: str | UsecolsArgType = ...,
    dtype: str | Dtype | Mapping[str, str | Dtype] | None = ...,
    engine: ExcelReadEngine | None = ...,
    converters: Mapping[int | str, Callable[[Any], Any]] | None = ...,
    true_values: Iterable[Hashable] | None = ...,
    false_values: Iterable[Hashable] | None = ...,
    skiprows: int | Sequence[int] | Callable[[object], bool] | None = ...,
    nrows: int | None = ...,
    na_values: Sequence[str] | dict[str | int, Sequence[str]] | None = ...,
    keep_default_na: bool = ...,
    na_filter: bool = ...,
    verbose: bool = ...,
    parse_dates: (
        bool
        | Sequence[int]
        | Sequence[Sequence[str] | Sequence[int]]
        | dict[str, Sequence[int] | list[str]]
    ) = ...,
    date_format: dict[Hashable, str] | str | None = ...,
    thousands: str | None = ...,
    decimal: str = ...,
    comment: str | None = ...,
    skipfooter: int = ...,
    storage_options: StorageOptions = ...,
    dtype_backend: DtypeBackend | NoDefault = ...,
    engine_kwargs: dict[str, Any] | None = ...,
) -> dict[int | str, DataFrame]: ...
@overload
def read_excel(
    io: (
        FilePath
        | ReadBuffer[bytes]
        | ExcelFile
        | Workbook
        | Book
        | OpenDocument
        | PyXlsbWorkbook
    ),
    sheet_name: int | str = ...,
    *,
    header: int | Sequence[int] | None = ...,
    names: ListLikeHashable | None = ...,
    index_col: int | Sequence[int] | str | None = ...,
    usecols: str | UsecolsArgType = ...,
    dtype: str | Dtype | Mapping[str, str | Dtype] | None = ...,
    engine: ExcelReadEngine | None = ...,
    converters: Mapping[int | str, Callable[[Any], Any]] | None = ...,
    true_values: Iterable[Hashable] | None = ...,
    false_values: Iterable[Hashable] | None = ...,
    skiprows: int | Sequence[int] | Callable[[object], bool] | None = ...,
    nrows: int | None = ...,
    na_values: Sequence[str] | dict[str | int, Sequence[str]] | None = ...,
    keep_default_na: bool = ...,
    na_filter: bool = ...,
    verbose: bool = ...,
    parse_dates: (
        bool
        | Sequence[int]
        | Sequence[Sequence[str] | Sequence[int]]
        | dict[str, Sequence[int] | list[str]]
    ) = ...,
    date_format: dict[Hashable, str] | str | None = ...,
    thousands: str | None = ...,
    decimal: str = ...,
    comment: str | None = ...,
    skipfooter: int = ...,
    storage_options: StorageOptions = ...,
    dtype_backend: DtypeBackend | NoDefault = ...,
    engine_kwargs: dict[str, Any] | None = ...,
) -> DataFrame: ...

ExcelWriteWorkbook: TypeAlias = Workbook | OpenDocument | XlsxWorkbook

_WorkbookT = TypeVar("_WorkbookT", default=ExcelWriteWorkbook, bound=ExcelWriteWorkbook)

class ExcelWriter(Generic[_WorkbookT]):
    @overload
    def __new__(
        cls,
        path: FilePath | BinaryIO,
        engine: Literal["openpyxl"],
        date_format: str | None = None,
        datetime_format: str | None = None,
        mode: Literal["w", "a"] = "w",
        storage_options: StorageOptions = None,
        if_sheet_exists: ExcelWriterIfSheetExists | None = None,
        engine_kwargs: Mapping[str, Any] | None = None,
    ) -> ExcelWriter[Workbook]: ...
    @overload
    def __new__(
        cls,
        path: FilePath | BinaryIO,
        engine: Literal["odf"],
        date_format: str | None = None,
        datetime_format: str | None = None,
        mode: Literal["w", "a"] = "w",
        storage_options: StorageOptions = None,
        if_sheet_exists: ExcelWriterIfSheetExists | None = None,
        engine_kwargs: Mapping[str, Any] | None = None,
    ) -> ExcelWriter[OpenDocument]: ...
    @overload
    def __new__(
        cls,
        path: FilePath | BinaryIO,
        engine: Literal["xlsxwriter"],
        date_format: str | None = None,
        datetime_format: str | None = None,
        mode: Literal["w", "a"] = "w",
        storage_options: StorageOptions = None,
        if_sheet_exists: ExcelWriterIfSheetExists | None = None,
        engine_kwargs: Mapping[str, Any] | None = None,
    ) -> ExcelWriter[XlsxWorkbook]: ...
    @overload
    def __new__(
        cls,
        path: FilePath | BinaryIO,
        engine: Literal["auto"] | None = None,
        date_format: str | None = None,
        datetime_format: str | None = None,
        mode: Literal["w", "a"] = "w",
        storage_options: StorageOptions = None,
        if_sheet_exists: ExcelWriterIfSheetExists | None = None,
        engine_kwargs: Mapping[str, Any] | None = None,
    ) -> ExcelWriter[ExcelWriteWorkbook]: ...
    @property
    def supported_extensions(self) -> tuple[str, ...]: ...
    @property
    def engine(self) -> ExcelWriteEngine: ...
    @property
    def sheets(self) -> dict[str, Any]: ...
    @property
    def book(self) -> _WorkbookT: ...
    @property
    def date_format(self) -> str: ...
    @property
    def datetime_format(self) -> str: ...
    @property
    def if_sheet_exists(self) -> Literal["error", "new", "replace", "overlay"]: ...
    def __fspath__(self) -> str: ...
    def __enter__(self) -> Self: ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
        /,
    ) -> None: ...
    def close(self) -> None: ...

class ExcelFile:
    def __init__(
        self,
        path_or_buffer: FilePath | ReadBuffer[bytes] | bytes,
        engine: ExcelReadEngine | None = ...,
        storage_options: StorageOptions = ...,
        engine_kwargs: dict[str, Any] | None = ...,
    ) -> None: ...
    def __fspath__(self) -> str: ...
    @overload
    def parse(
        self,
        sheet_name: list[int | str] | None,
        header: int | Sequence[int] | None = ...,
        names: ListLikeHashable | None = ...,
        index_col: int | Sequence[int] | None = ...,
        usecols: str | UsecolsArgType = ...,
        converters: dict[int | str, Callable[[Any], Any]] | None = ...,
        true_values: Iterable[Hashable] | None = ...,
        false_values: Iterable[Hashable] | None = ...,
        skiprows: int | Sequence[int] | Callable[[object], bool] | None = ...,
        nrows: int | None = ...,
        na_values: Sequence[str] | dict[str | int, Sequence[str]] = ...,
        parse_dates: (
            bool
            | Sequence[int]
            | Sequence[Sequence[str] | Sequence[int]]
            | dict[str, Sequence[int] | list[str]]
        ) = ...,
        date_parser: Callable[..., Any] | None = ...,
        thousands: str | None = ...,
        comment: str | None = ...,
        skipfooter: int = ...,
        keep_default_na: bool = ...,
        na_filter: bool = ...,
        **kwds: Any,
    ) -> dict[int | str, DataFrame]: ...
    @overload
    def parse(
        self,
        sheet_name: int | str,
        header: int | Sequence[int] | None = ...,
        names: ListLikeHashable | None = ...,
        index_col: int | Sequence[int] | None = ...,
        usecols: str | UsecolsArgType = ...,
        converters: dict[int | str, Callable[[Any], Any]] | None = ...,
        true_values: Iterable[Hashable] | None = ...,
        false_values: Iterable[Hashable] | None = ...,
        skiprows: int | Sequence[int] | Callable[[object], bool] | None = ...,
        nrows: int | None = ...,
        na_values: Sequence[str] | dict[str | int, Sequence[str]] = ...,
        parse_dates: (
            bool
            | Sequence[int]
            | Sequence[Sequence[str] | Sequence[int]]
            | dict[str, Sequence[int] | list[str]]
        ) = ...,
        date_parser: Callable[..., Any] | None = ...,
        thousands: str | None = ...,
        comment: str | None = ...,
        skipfooter: int = ...,
        keep_default_na: bool = ...,
        na_filter: bool = ...,
        **kwds: Any,
    ) -> DataFrame: ...
    @property
    def book(self) -> Workbook | Book | OpenDocument | PyXlsbWorkbook: ...
    @property
    def sheet_names(self) -> list[int | str]: ...
    def close(self) -> None: ...
    def __enter__(self) -> Self: ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
        /,
    ) -> None: ...
    def __del__(self) -> None: ...

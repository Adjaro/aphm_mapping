from collections.abc import (
    Iterable,
    Mapping,
    Sequence,
)
from typing import (
    Literal,
    Never,
    TypeVar,
    overload,
)

from pandas.core.frame import DataFrame
from pandas.core.generic import NDFrame
from pandas.core.series import Series

from pandas._typing import (
    S2,
    Axis,
    AxisColumn,
    AxisIndex,
    HashableT1,
    HashableT2,
    HashableT3,
    HashableT4,
)

DataFrameT0 = TypeVar("DataFrameT0", bound=DataFrame)

@overload
def concat(
    objs: Iterable[None] | Mapping[HashableT1, None],
    *,
    axis: Axis = 0,
    join: Literal["inner", "outer"] = "outer",
    ignore_index: bool = False,
    keys: Iterable[HashableT2] | None = None,
    levels: Sequence[list[HashableT3] | tuple[HashableT3, ...]] | None = None,
    names: list[HashableT4] | None = None,
    verify_integrity: bool = False,
    sort: bool = False,
) -> Never: ...
@overload
def concat(
    objs: Iterable[NDFrame | None] | Mapping[HashableT1, NDFrame | None],
    *,
    axis: Axis = 0,
    join: Literal["inner", "outer"] = "outer",
    ignore_index: Literal[True],
    keys: Iterable[HashableT2],
    levels: Sequence[list[HashableT3] | tuple[HashableT3, ...]] | None = None,
    names: list[HashableT4] | None = None,
    verify_integrity: bool = False,
    sort: bool = False,
) -> Never: ...
@overload
def concat(  # type: ignore[overload-overlap] # pyright: ignore[reportOverlappingOverload]
    objs: Iterable[Series[S2] | None] | Mapping[HashableT1, Series[S2] | None],
    *,
    axis: AxisIndex = 0,
    join: Literal["inner", "outer"] = "outer",
    ignore_index: bool = False,
    keys: Iterable[HashableT2] | None = None,
    levels: Sequence[list[HashableT3] | tuple[HashableT3, ...]] | None = None,
    names: list[HashableT4] | None = None,
    verify_integrity: bool = False,
    sort: bool = False,
) -> Series[S2]: ...
@overload
def concat(  # type: ignore[overload-overlap]
    objs: Iterable[Series | None] | Mapping[HashableT1, Series | None],
    *,
    axis: AxisIndex = 0,
    join: Literal["inner", "outer"] = "outer",
    ignore_index: bool = False,
    keys: Iterable[HashableT2] | None = None,
    levels: Sequence[list[HashableT3] | tuple[HashableT3, ...]] | None = None,
    names: list[HashableT4] | None = None,
    verify_integrity: bool = False,
    sort: bool = False,
) -> Series: ...
@overload
def concat(
    objs: Iterable[Series | None] | Mapping[HashableT1, Series | None],
    *,
    axis: AxisColumn,
    join: Literal["inner", "outer"] = "outer",
    ignore_index: bool = False,
    keys: Iterable[HashableT2] | None = None,
    levels: Sequence[list[HashableT3] | tuple[HashableT3, ...]] | None = None,
    names: list[HashableT4] | None = None,
    verify_integrity: bool = False,
    sort: bool = False,
) -> DataFrame: ...
@overload
def concat(
    objs: Iterable[DataFrameT0 | None] | Mapping[HashableT1, DataFrameT0 | None],
    *,
    axis: Axis = 0,
    join: Literal["inner", "outer"] = "outer",
    ignore_index: bool = False,
    keys: Iterable[HashableT2] | None = None,
    levels: Sequence[list[HashableT3] | tuple[HashableT3, ...]] | None = None,
    names: list[HashableT4] | None = None,
    verify_integrity: bool = False,
    sort: bool = False,
) -> DataFrameT0: ...
@overload
def concat(
    objs: Iterable[NDFrame | None] | Mapping[HashableT1, NDFrame | None],
    *,
    axis: Axis = 0,
    join: Literal["inner", "outer"] = "outer",
    ignore_index: Literal[False] = False,
    keys: Iterable[HashableT2] | None = None,
    levels: Sequence[list[HashableT3] | tuple[HashableT3, ...]] | None = None,
    names: list[HashableT4] | None = None,
    verify_integrity: bool = False,
    sort: bool = False,
) -> DataFrame: ...
